import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../widgets/souqna_bottom_sheet.dart';
import '../widgets/souqna_button.dart';
import '../widgets/souqna_text_field.dart';

class BankAccountsScreen extends StatefulWidget {
  const BankAccountsScreen({super.key});

  @override
  State<BankAccountsScreen> createState() => _BankAccountsScreenState();
}

class _BankAccountsScreenState extends State<BankAccountsScreen> {
  final List<Map<String, String>> _accounts = [
    {'bank': 'مصرف الراجحي', 'iban': 'SA03 8000 0000 6080 1016 7519'},
  ];

  String _mask(String iban) {
    final c = iban.replaceAll(' ', '');
    if (c.length < 8) return iban;
    return '${c.substring(0, 4)} •••• •••• ${c.substring(c.length - 4)}';
  }

  void _add() {
    final bank = TextEditingController();
    final iban = TextEditingController();
    final key = GlobalKey<FormState>();

    showSouqnaBottomSheet<void>(
      context: context,
      title: 'إضافة حساب بنكي',
      child: Form(
        key: key,
        child: Column(
          children: [
            SouqnaTextField(controller: bank, hint: 'اسم البنك', validator: (v) => (v ?? '').trim().isEmpty ? 'مطلوب' : null),
            const SizedBox(height: 10),
            SouqnaTextField(
              controller: iban,
              hint: 'SA00 0000 0000 0000 0000 0000',
              validator: (v) {
                final c = (v ?? '').replaceAll(' ', '').toUpperCase();
                return RegExp(r'^SA\d{22}$').hasMatch(c) ? null : 'آيبان غير صحيح (SA + 22 رقم)';
              },
            ),
            const SizedBox(height: 16),
            SouqnaButton(
              title: 'حفظ',
              onPressed: () {
                if (!key.currentState!.validate()) return;
                final clean = iban.text.replaceAll(' ', '').toUpperCase();
                if (_accounts.any((a) => a['iban']!.replaceAll(' ', '') == clean)) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('هذا الآيبان مضاف مسبقاً')));
                  return;
                }
                setState(() => _accounts.add({'bank': bank.text.trim(), 'iban': iban.text.trim().toUpperCase()}));
                Navigator.of(context).pop();
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('الحسابات البنكية')),
        floatingActionButton: FloatingActionButton(
          backgroundColor: SouqnaColors.accent,
          foregroundColor: Colors.white,
          onPressed: _add,
          child: const Icon(Icons.add),
        ),
        body: ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: _accounts.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (ctx, i) {
            final a = _accounts[i];
            return Dismissible(
              key: ValueKey(a['iban']),
              direction: DismissDirection.startToEnd,
              background: Container(
                alignment: Alignment.centerRight,
                padding: const EdgeInsets.symmetric(horizontal: 20),
                decoration: BoxDecoration(color: Colors.red.shade400, borderRadius: BorderRadius.circular(16)),
                child: const Icon(Icons.delete_outline, color: Colors.white),
              ),
              onDismissed: (_) => setState(() => _accounts.removeAt(i)),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: SouqnaColors.border)),
                child: Row(
                  children: [
                    const Icon(Icons.account_balance_rounded, color: SouqnaColors.primary),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(a['bank']!, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                          const SizedBox(height: 2),
                          Directionality(
                            textDirection: TextDirection.ltr,
                            child: Text(_mask(a['iban']!), style: const TextStyle(fontSize: 12, color: SouqnaColors.textSecondary)),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
